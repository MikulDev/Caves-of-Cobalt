Select your GUI here to enable inventory and GUI binding on this item.

Set to Empty to disable inventory (you want this in most cases).

Enabling inventory will make this item unstackable.