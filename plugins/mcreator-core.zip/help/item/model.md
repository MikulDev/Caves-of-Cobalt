Select the model to be used with this item. Model only defines visual look.

* **Normal** - Normal item
* Custom - you can define custom JSON and OBJ models too

When making custom models, JSON is recommended due to vanilla support for this model type.