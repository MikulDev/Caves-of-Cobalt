The item texture representing the bullet. Bullet will look the same as the item selected here.

For custom shapes, use bullet model parameter.