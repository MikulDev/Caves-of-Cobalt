Use this field to define where the spawning should happen.

If the list is empty, spawning will be disabled.