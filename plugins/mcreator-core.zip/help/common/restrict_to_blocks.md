Use this field to define on which block(s) the spawning will happen.

If the list is empty, this option will be disabled, and it will be able to spawn on all blocks.