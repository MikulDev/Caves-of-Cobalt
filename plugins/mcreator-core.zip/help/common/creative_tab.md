This is where your block will be in creative mode.
Use tabs with CUSTOM: prefix to use custom tabs.