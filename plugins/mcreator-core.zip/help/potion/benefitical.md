Check this parameter in case if your effect is beneficial for the player 

Example: Regeneration or Instant Health.