This parameter controls the number of trees (the type you selected) per biome chunk.

Set to 0 to disable trees.