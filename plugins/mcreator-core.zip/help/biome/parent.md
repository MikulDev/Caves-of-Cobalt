Your biome will always spawn near to the biome selected (it will be used for biome borders and transitions).

Example: Deep ocean always spawns near ocean biome.