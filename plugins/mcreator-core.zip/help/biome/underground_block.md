This parameter controls the underground block below the ground block layer.

Generally, vanilla or custom dirt is used here for most biomes.