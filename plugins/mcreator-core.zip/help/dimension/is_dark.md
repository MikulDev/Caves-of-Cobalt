If this parameter is checked, global light source is disabled and dimension will be dark.

If even skylight is disabled, this dimension will have no natural light source.

Keep skylight enabled for nether dimensions in all cases, unless the dimension should be completely dark.