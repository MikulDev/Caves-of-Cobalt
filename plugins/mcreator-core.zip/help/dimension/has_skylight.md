This parameter will make the dimension have skylight in a similar way as overworld with daynight cycle.

Keep in mind that skylight does not propagate through blocks, so nether dimensions with skylight will
still be dark and need Global light source enabled to not be dark.