Check this parameter to enable dense fog in the dimension, even if the render
distance is set to big values.