This parameter controls how fast your tool can be used. 

The higher the value is, the faster the tool will attack.