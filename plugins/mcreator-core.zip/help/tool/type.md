The type of tool this tool is.

Some of the parameters below are not used by some of the tool types.