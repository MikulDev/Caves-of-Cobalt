This parameter defines the priority of your overlay. Overlays with "High" will be rendered above
overlays with this parameter set to "Low".