A base texture for your overlay. Other components will be drawn over this texture.

This parameter can be used to make "pumpkin" like overlays.