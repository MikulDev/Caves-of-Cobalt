Sets the average number of ore veins to spawn per chunk.

Vanilla ore group per chunk values:

* Coal Ore - 20
* Iron Ore - 20
* Gold Ore - 2
* Redstone Ore - 8
* Diamond Ore - 1
* Lapis Lazuli - 1