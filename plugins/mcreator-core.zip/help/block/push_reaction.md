This parameter determines how the block reacts with a piston.

* Normal: Normal reaction of pistons like the Stone
* Destroy: When the block will be pushed by a piston, the block will be destroyed.
* Block: The block don't react to a piston like the Obsidian.
* Push Only: The block can be only pushed by a piston.