This parameter should only be used in combination with transparent blocks.

This will make internal sides of the block connect similar to how glass, ice and
other similar blocks do this.