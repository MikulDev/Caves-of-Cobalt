This parameter determines how quickly the block is consumed by fire.

Vanilla examples: 
* logs have a flammability of 5
* planks have a flammability of 20