This parameter defines a custom item or block that is dropped when this block is mined/broken.

If harvest level is used, only proper level harvest tools will make the block drop.