If checked, entities will be able to climb on the block. 

Vanilla examples: Ladder and Vines