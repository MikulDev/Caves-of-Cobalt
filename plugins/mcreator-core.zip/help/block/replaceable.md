If you check this parameter, the player will be able to place another block 
on it (this block can be replaced by other blocks being placed).

Examples: air, most plants