If this parameter is checked, the block can be used to make a beacon base. 

Vanilla beacon base blocks:

* Iron Block
* Gold Block
* Diamond Block
* Emerald Block 