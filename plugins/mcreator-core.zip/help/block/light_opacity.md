This property makes the block allow (1) or not (0) the light to pass through, 
126 makes it semi-transparent (only in some Minecraft versions) and 255 will allow all light through.