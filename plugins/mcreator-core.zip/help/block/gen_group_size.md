This parameter controls the average amount of block per ore veins.

Vanilla ore group sizes:

* Coal Ore - 17
* Iron Ore - 9
* Gold Ore - 9
* Redstone Ore - 8
* Diamond Ore - 8
* Lapis Lazuli - 7