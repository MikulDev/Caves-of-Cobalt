This parameter controls how long it takes to mine the block. 
A higher value means it takes longer to mine this block.