This parameter controls what tool you want to mine the block.

Ores use pickaxe here, logs axe, for example.