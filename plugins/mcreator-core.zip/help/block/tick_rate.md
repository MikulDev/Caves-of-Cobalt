This parameter controls how often the block will tick. If tick randomly is selected, this parameter
has no effect.

Keep in mind that usually, blocks naturally generated will not tick by default, unless tick randomly
is used.

Default tick rate of 10 means the block will tick each 10 world ticks. There are 20 world ticks in
a second so this means the block will tick twice a second.