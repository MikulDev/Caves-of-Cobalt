This parameter controls spawning type for the biomes where his mob is defined to spawn in.

* A mob marked as Monster will only spawn in the dark or at night. 
* A mob marked as Creature will spawn under any conditions. 
* A mob marked as Ambient also spawns under any conditions, 
but this category should be used for mobs with no gameplay effect such as bats. 
* WaterCreature will spawn in water, but with no other limitations.

Spawn type system is in-depth explained [here](https://mcreator.net/wiki/mob-spawning-parameters)