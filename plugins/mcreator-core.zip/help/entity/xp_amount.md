This parameter controls the amount of experience earned from killing the mob. 

This parameter is usually 1-3 for an animal and 5 for a monster.