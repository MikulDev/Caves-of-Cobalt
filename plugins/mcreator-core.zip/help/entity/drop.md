The block/item the mob will drop when he dies. 

You can alternatively use loot tables to have more drops, and decide the rarity of each drop.