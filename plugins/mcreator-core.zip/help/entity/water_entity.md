Checking this parameter makes the entity a water entity.

Enabling this parameter will make the entity have water type navigator and motion controller.