The icon to identify the creative tab like the redstone powder for the redstone tab.

Only items are supported here. Blocks without item can not be shown as icon.