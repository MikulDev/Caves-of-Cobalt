This parameter controls in which crafting system your recipe will be available.

* Crafting is the crafting table.
* Smelting is furnace recipe.
* Blasting is a recipe inside the blast furnace.
* Smoking is a recipe inside the Smoker.
* Stone cutting is a Stone cutter recipe.
* Campfire cooking is a recipe for when we right click on a campfire